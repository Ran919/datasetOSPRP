ISG1-ISG6 instances and corresponding results

Each instance folder contains:
- instance.json: warehouse/instance parameters and depot coordinates
- sku_map.csv: all SKU storage coordinates, ABC class, precedence level
- orders.csv: order-SKU membership with coordinates and precedence levels
- routing_costs_B.csv: exact single-order routing cost B[o,startDepot,endDepot]
- result_summary.csv: DP-O and D-ALNS instance-level results from the completed experiment
- dp_o_solution.csv: one exact optimal order/depot sequence reconstructed for DP-O
- dalns_runs.csv: all 10 D-ALNS runs, objective/gap, and recovered best order/depot sequences

IDs in exported data are 1-based for MATLAB/paper readability.
Instance seed = 1000*ISG + Rep.
D-ALNS seed = ISG*1,000,000 + Rep*1000 + Run.
The recovered sequences were regenerated with the same deterministic seeds and verified to reproduce the previously recorded objective values exactly.

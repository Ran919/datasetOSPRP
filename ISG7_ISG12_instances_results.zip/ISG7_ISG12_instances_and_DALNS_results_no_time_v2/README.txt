ISG7--ISG12 large instances and D-ALNS-only results

Scope
- 6 large instance groups (ISG7--ISG12)
- 10 generated instances per group = 60 instances
- D-ALNS only
- 10 independent D-ALNS runs per instance = 600 runs
- No DP-O, LNS, M-sah, BI, or lower-bound calculation in this package

Per-instance files
- instance.json: instance/layout parameters, depots, random seed, D-ALNS parameters
- sku_map.csv: all SKU positions, ABC class and precedence level
- orders.csv: exact order contents
- routing_costs_B.csv: routing cost cache used by D-ALNS
- result_summary.csv: instance-level D-ALNS mean/best/std objective and timing

Master files
- manifest.csv
- master_instance_results.csv
- master_dalns_runs.csv
- master_orders.csv
- group_summary.csv

IDs in exported files are 1-based.
Instance seed = 1000*ISG + Rep.
D-ALNS seed = ISG*1,000,000 + Rep*1000 + Run.
The optimized exact routing-cache implementation was verified against the earlier exact implementation with elementwise maximum difference 0 on representative ISG1, ISG5, ISG7 and ISG11 instances.
